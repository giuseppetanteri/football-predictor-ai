import streamlit as st
import pandas as pd
import sqlite3, math, io
from datetime import datetime, date
from pathlib import Path

DB = Path("football_predictor.db")
LEAGUES = [
    "Serie A", "Premier League", "Liga", "Bundesliga", "Ligue 1",
    "Serie B", "Champions League", "Europa League", "Conference League"
]

st.set_page_config(page_title="Football Predictor AI", page_icon="⚽", layout="wide")

def db():
    con = sqlite3.connect(DB, check_same_thread=False)
    con.execute("""CREATE TABLE IF NOT EXISTS matches (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        league TEXT NOT NULL, match_date TEXT NOT NULL,
        home TEXT NOT NULL, away TEXT NOT NULL,
        home_goals INTEGER, away_goals INTEGER,
        source TEXT DEFAULT 'manual',
        UNIQUE(league, match_date, home, away)
    )""")
    con.execute("""CREATE TABLE IF NOT EXISTS predictions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL, league TEXT NOT NULL,
        match_date TEXT, home TEXT NOT NULL, away TEXT NOT NULL,
        lambda_home REAL, lambda_away REAL,
        p_home REAL, p_draw REAL, p_away REAL,
        p_over25 REAL, p_btts REAL,
        predicted_home_goals INTEGER, predicted_away_goals INTEGER,
        model_version TEXT DEFAULT 'poisson-elo-v0.1'
    )""")
    con.commit()
    return con

con = db()

def poisson_probs(lam, max_goals=10):
    probs = [math.exp(-lam)]
    for k in range(1, max_goals + 1):
        probs.append(probs[-1] * lam / k)
    total = sum(probs)
    return [p / total for p in probs]

def elo_ratings(matches, base=1500, k=24):
    ratings = {}
    rows = matches.sort_values("match_date")
    for r in rows.itertuples():
        h, a = r.home, r.away
        rh, ra = ratings.get(h, base), ratings.get(a, base)
        expected_h = 1 / (1 + 10 ** ((ra - (rh + 60)) / 400))
        result_h = 1 if r.home_goals > r.away_goals else (0.5 if r.home_goals == r.away_goals else 0)
        margin = abs(r.home_goals - r.away_goals)
        change = k * (1 + min(margin, 3) * 0.15) * (result_h - expected_h)
        ratings[h] = rh + change
        ratings[a] = ra - change
    return ratings

def team_strengths(matches, league, home, away):
    m = matches[(matches.league == league) & matches.home_goals.notna() & matches.away_goals.notna()].copy()
    if len(m) < 10:
        raise ValueError(f"Servono almeno 10 partite concluse del campionato selezionato. Al momento: {len(m)}.")
    avg_home = m.home_goals.mean()
    avg_away = m.away_goals.mean()
    if avg_home <= 0 or avg_away <= 0:
        raise ValueError("Dati insufficienti per stimare i gol medi.")
    # Recency weighting: recent matches carry more weight, but older matches remain useful.
    m = m.sort_values("match_date").tail(250).copy()
    m["weight"] = [0.985 ** (len(m)-1-i) for i in range(len(m))]
    ratings = elo_ratings(m)
    def weighted_mean(series, weights):
        return float((series * weights).sum() / weights.sum())
    home_rows = m[m.home == home]
    away_rows = m[m.away == away]
    # fallback to all matches involving team, with venue split preferred
    h_scored = weighted_mean(home_rows.home_goals, home_rows.weight) if len(home_rows) >= 3 else weighted_mean(m[m.home == home].home_goals, m[m.home == home].weight) if (m.home == home).any() else avg_home
    h_conceded = weighted_mean(home_rows.away_goals, home_rows.weight) if len(home_rows) >= 3 else avg_away
    a_scored = weighted_mean(away_rows.away_goals, away_rows.weight) if len(away_rows) >= 3 else avg_away
    a_conceded = weighted_mean(away_rows.home_goals, away_rows.weight) if len(away_rows) >= 3 else avg_home
    # shrink rates toward league averages to reduce small-sample overreaction
    h_attack = (h_scored + 5 * avg_home) / (avg_home + 5 * avg_home)
    h_defence = (h_conceded + 5 * avg_away) / (avg_away + 5 * avg_away)
    a_attack = (a_scored + 5 * avg_away) / (avg_away + 5 * avg_away)
    a_defence = (a_conceded + 5 * avg_home) / (avg_home + 5 * avg_home)
    elo_diff = ratings.get(home, 1500) - ratings.get(away, 1500)
    elo_factor = max(0.82, min(1.18, 1 + elo_diff / 2500))
    lam_h = max(0.15, min(3.5, avg_home * h_attack * a_defence * elo_factor))
    lam_a = max(0.15, min(3.5, avg_away * a_attack * h_defence / elo_factor))
    return lam_h, lam_a, len(m), elo_diff

def predict(lh, la):
    ph, pa = poisson_probs(lh), poisson_probs(la)
    p1 = px = p2 = over25 = btts = 0.0
    score_grid = []
    for h, hp in enumerate(ph):
        for a, ap in enumerate(pa):
            p = hp * ap
            if h > a: p1 += p
            elif h == a: px += p
            else: p2 += p
            if h + a >= 3: over25 += p
            if h > 0 and a > 0: btts += p
            score_grid.append((p, h, a))
    score_grid.sort(reverse=True)
    return p1, px, p2, over25, btts, score_grid[:5]

def normalise_csv(df, league):
    aliases = {
        "date":"match_date", "Date":"match_date", "match_date":"match_date",
        "home":"home", "HomeTeam":"home", "home_team":"home",
        "away":"away", "AwayTeam":"away", "away_team":"away",
        "ft_home":"home_goals", "FTHG":"home_goals", "home_goals":"home_goals",
        "ft_away":"away_goals", "FTAG":"away_goals", "away_goals":"away_goals",
        "league":"league"
    }
    df = df.rename(columns={c: aliases[c] for c in df.columns if c in aliases})
    required = ["match_date", "home", "away"]
    if not all(c in df.columns for c in required):
        raise ValueError("CSV non riconosciuto. Servono almeno: date, home, away. Per i risultati aggiungi ft_home e ft_away.")
    if "league" not in df.columns:
        df["league"] = league
    df["match_date"] = pd.to_datetime(df["match_date"], errors="coerce").dt.strftime("%Y-%m-%d")
    if "home_goals" not in df.columns: df["home_goals"] = pd.NA
    if "away_goals" not in df.columns: df["away_goals"] = pd.NA
    df["home_goals"] = pd.to_numeric(df["home_goals"], errors="coerce")
    df["away_goals"] = pd.to_numeric(df["away_goals"], errors="coerce")
    df = df.dropna(subset=["match_date", "home", "away"])
    df["league"] = df["league"].fillna(league).astype(str)
    return df[["league","match_date","home","away","home_goals","away_goals"]]

st.title("⚽ FOOTBALL PREDICTOR AI")
st.caption("Prototype v0.1 · Motore statistico Poisson + Elo · Nessuna previsione garantita")
tab1, tab2, tab3, tab4 = st.tabs(["📊 Dashboard", "🧠 Analizza partita", "📥 Database", "📈 Verifica modello"])

with tab1:
    data = pd.read_sql_query("SELECT * FROM matches", con)
    preds = pd.read_sql_query("SELECT * FROM predictions", con)
    c1,c2,c3 = st.columns(3)
    c1.metric("Partite archiviate", len(data))
    c2.metric("Previsioni registrate", len(preds))
    c3.metric("Campionati", data.league.nunique() if len(data) else 0)
    st.subheader("Ultime previsioni")
    if len(preds):
        st.dataframe(preds.sort_values("id", ascending=False).head(15), use_container_width=True, hide_index=True)
    else:
        st.info("Non ci sono ancora previsioni. Vai su 'Analizza partita' per crearne una.")

with tab2:
    st.subheader("Analisi pre-partita")
    d = pd.read_sql_query("SELECT DISTINCT league FROM matches", con)
    available = sorted(d.league.dropna().tolist())
    league = st.selectbox("Campionato", LEAGUES, index=0)
    teams = pd.read_sql_query("SELECT home AS team FROM matches WHERE league=? UNION SELECT away AS team FROM matches WHERE league=? ORDER BY team", con, params=(league,league))
    team_names = teams.team.tolist()
    col1,col2 = st.columns(2)
    with col1:
        home = st.selectbox("Squadra in casa", team_names if team_names else ["Carica prima i dati"])
    with col2:
        away_options = [x for x in team_names if x != home]
        away = st.selectbox("Squadra in trasferta", away_options if away_options else ["Carica prima i dati"])
    match_day = st.date_input("Data partita", value=date.today())
    if st.button("Calcola pronostico", type="primary", use_container_width=True):
        try:
            if not team_names or home == away or away not in team_names:
                st.error("Carica prima le partite storiche e seleziona due squadre diverse.")
            else:
                hist = pd.read_sql_query("SELECT * FROM matches", con)
                lh, la, n, elo_diff = team_strengths(hist, league, home, away)
                p1, px, p2, ov, btts, scores = predict(lh,la)
                st.markdown("### Probabilità stimate")
                a,b,c = st.columns(3)
                a.metric("1 · Casa", f"{p1:.1%}")
                b.metric("X · Pareggio", f"{px:.1%}")
                c.metric("2 · Trasferta", f"{p2:.1%}")
                x,y,z = st.columns(3)
                x.metric("Over 2.5", f"{ov:.1%}")
                y.metric("Under 2.5", f"{1-ov:.1%}")
                z.metric("Goal", f"{btts:.1%}")
                st.write(f"Gol attesi: **{home} {lh:.2f} – {la:.2f} {away}** · Elo differenziale: {elo_diff:+.0f} · Campione: {n} partite")
                st.write("Risultati esatti più probabili (stima):")
                st.dataframe(pd.DataFrame([{"Risultato":f"{h}-{a}","Probabilità":f"{p:.1%}"} for p,h,a in scores]), hide_index=True, use_container_width=True)
                con.execute("""INSERT INTO predictions
                (created_at,league,match_date,home,away,lambda_home,lambda_away,p_home,p_draw,p_away,p_over25,p_btts,predicted_home_goals,predicted_away_goals)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (datetime.now().isoformat(timespec="seconds"),league,match_day.isoformat(),home,away,lh,la,p1,px,p2,ov,btts,scores[0][1],scores[0][2]))
                con.commit()
                st.success("Previsione salvata nello storico.")
        except Exception as e:
            st.error(str(e))

with tab3:
    st.subheader("Importa partite nel database")
    st.write("Carica un CSV con date, squadre e risultati. Puoi importare risultati storici e, se vuoi, partite future senza gol.")
    st.download_button("Scarica CSV modello", data="date,league,home,away,ft_home,ft_away\n2026-08-15,Serie A,Team A,Team B,2,1\n", file_name="football_template.csv", mime="text/csv")
    upload = st.file_uploader("Scegli file CSV", type=["csv"])
    default_league = st.selectbox("Campionato da assegnare se manca la colonna league", LEAGUES, key="import_league")
    if upload is not None:
        try:
            raw = pd.read_csv(upload)
            clean = normalise_csv(raw, default_league)
            st.write(f"Anteprima: {len(clean)} righe")
            st.dataframe(clean.head(10), use_container_width=True, hide_index=True)
            if st.button("Importa nel database", type="primary"):
                rows = [(r.league,r.match_date,r.home,r.away,None if pd.isna(r.home_goals) else int(r.home_goals),None if pd.isna(r.away_goals) else int(r.away_goals)) for r in clean.itertuples()]
                con.executemany("""INSERT OR REPLACE INTO matches (league,match_date,home,away,home_goals,away_goals) VALUES (?,?,?,?,?,?)""", rows)
                con.commit()
                st.success(f"Importate/aggiornate {len(rows)} partite.")
        except Exception as e:
            st.error(f"Errore CSV: {e}")
    st.divider()
    stored = pd.read_sql_query("SELECT * FROM matches ORDER BY match_date DESC", con)
    st.write("Archivio attuale")
    st.dataframe(stored, use_container_width=True, hide_index=True)
    if st.button("Esporta database partite CSV"):
        st.download_button("Scarica archivio", stored.to_csv(index=False).encode("utf-8"), "football_matches_export.csv", "text/csv")

with tab4:
    st.subheader("Controllo qualità delle previsioni")
    st.write("Le metriche si attiveranno quando saranno disponibili previsioni salvate prima delle partite e relativi risultati.")
    pp = pd.read_sql_query("SELECT * FROM predictions", con)
    actual = pd.read_sql_query("""SELECT p.*, m.home_goals AS actual_home, m.away_goals AS actual_away
        FROM predictions p JOIN matches m
        ON p.league=m.league AND p.match_date=m.match_date AND p.home=m.home AND p.away=m.away
        WHERE m.home_goals IS NOT NULL AND m.away_goals IS NOT NULL""", con)
    if len(actual):
        actual["actual_outcome"] = actual.apply(lambda r: 1 if r.actual_home>r.actual_away else (0 if r.actual_home==r.actual_away else 2), axis=1)
        actual["brier_1x2"] = actual.apply(lambda r: (r.p_home-(r.actual_outcome==1))**2 + (r.p_draw-(r.actual_outcome==0))**2 + (r.p_away-(r.actual_outcome==2))**2, axis=1)
        actual["correct"] = actual.apply(lambda r: int([r.p_home,r.p_draw,r.p_away].index(max(r.p_home,r.p_draw,r.p_away)) == r.actual_outcome), axis=1)
        a,b = st.columns(2)
        a.metric("Previsioni verificate", len(actual))
        b.metric("Accuratezza 1X2", f"{actual.correct.mean():.1%}")
        st.metric("Brier Score 1X2 (più basso è meglio)", f"{actual.brier_1x2.mean():.3f}")
        st.dataframe(actual[["match_date","league","home","away","actual_home","actual_away","correct","brier_1x2"]], use_container_width=True, hide_index=True)
    else:
        st.info("Nessuna previsione ancora verificabile. Importa i risultati dopo le partite: devono corrispondere a campionato, data, squadra casa e squadra trasferta.")
    st.warning("Attenzione: questo è un prototipo iniziale. Il modello non è ancora validato, non considera infortuni/formazioni/xG e non deve essere interpretato come garanzia di vincita.")

st.divider()
st.caption("Football Predictor AI · Prototype v0.1 · Strumento statistico a scopo informativo. Gioco responsabile.")
