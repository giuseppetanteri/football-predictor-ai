# Football Predictor AI — Prototype v0.1

## Avvio gratuito sul tuo computer

1. Installa Python 3.11 o 3.12.
2. Estrai la cartella ZIP.
3. Apri il terminale nella cartella del progetto.
4. Esegui:

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

Si aprirà la web app nel browser.

## Primo utilizzo

1. Apri la scheda **Database**.
2. Scarica il CSV modello.
3. Prepara un CSV con colonne `date,league,home,away,ft_home,ft_away`.
4. Importa almeno 10 partite concluse per il campionato che vuoi analizzare.
5. Vai su **Analizza partita**, scegli due squadre e calcola una previsione.
6. Dopo la partita, importa il risultato reale con le stesse squadre, data e competizione.
7. Controlla **Verifica modello**.

## Cosa fa il modello v0.1

- Poisson indipendente per stimare i gol e derivare 1X2, Over/Under 2.5 e Goal.
- Elo sequenziale semplice, aggiornato sui risultati storici.
- Ponderazione temporale e regressione verso la media del campionato.
- Salvataggio locale SQLite di partite e previsioni.
- Verifica con accuratezza 1X2 e Brier Score.

## Limiti da conoscere

- Il prototipo non scarica automaticamente i dati e non ha ancora login o pagamenti.
- Le competizioni UEFA e i campionati nazionali hanno calendari e strutture differenti: vanno mantenuti separati nel database.
- Servono dati sufficienti e puliti; almeno 10 partite è un minimo tecnico, non una soglia di affidabilità scientifica.
- Il modello non usa ancora formazioni, infortuni, xG, calendario, quote o fattori tattici.
- La persistenza SQLite è adatta al prototipo locale; per una versione online multiutente servirà un database gestito.
- Prima della commercializzazione, verificare licenze e diritti di ogni fonte dati. Alcuni dataset gratuiti sono limitati all'uso personale o vietano uso commerciale/AI.

## Dati e licenze

Non incorporiamo dati di terzi nel progetto. Importa solo dati che hai il diritto di usare.
